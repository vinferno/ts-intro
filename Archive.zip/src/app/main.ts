console.log('test');
let text: string | undefined  = '';
const input = document.querySelector('input');

text = input?.value;